const db = require('../../connection/railwayDBConfig');

async function insertUser(user) {
  const sql = `
    INSERT INTO users (username, password_hash, nickname, gender, birth_date, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `;

  const params = [
    user.username,
    user.password,     // 先直接存明文到password_hash，後面再改加密
    user.nickname,
    user.gender,
    user.birth,
    user.email,
    user.phone
  ];

  const [result] = await db.execute(sql, params);
  return { id: result.insertId };
}

module.exports = {
  insertUser,
};
