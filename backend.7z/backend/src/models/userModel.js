// model/userModel.js

const UserDAO = require('./dao/userDAO');
const UserDTO = require('./dto/userDTO');

async function createUser(userDto) {
	const user = new UserDTO(userDto);  // 格式標準化、驗證欄位
	return UserDAO.insertUser(user);    // 寫入資料庫
}

module.exports = {
	createUser,
};
