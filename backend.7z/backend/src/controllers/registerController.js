const userModel = require('../models/userModel');

exports.registerUser = async (req, res) => {
  try {
    const userDto = req.body;
    await userModel.createUser(userDto);
    res.status(201).json({ message: '註冊成功' });
  } catch (err) {
    res.status(500).json({ error: '註冊失敗', detail: err.message });
  }
};
