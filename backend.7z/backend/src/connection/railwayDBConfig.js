// connection/railwayDBConfig.js
const mysql = require('mysql2');
require('dotenv').config();  // 載入 .env 環境變數

// 建立連線
const connection = mysql.createConnection({
  host: process.env.RAILWAY_DB_HOST,
  port: process.env.RAILWAY_DB_PORT,  // 可選，如果 .env 有設定 PORT
  user: process.env.RAILWAY_DB_USER,
  password: process.env.RAILWAY_DB_PASSWORD,
  database: process.env.RAILWAY_DB_NAME
});

// 連線驗證
connection.connect(err => {
  if (err) {
    console.error('資料庫連線失敗:', err);
    return;
  }
  console.log('已連接到 Railway 的 MySQL 資料庫');
});

// 匯出連線物件
module.exports = connection;
